//
// Created by os on 9/25/23.
//

#ifndef PROJEKAT2_TESTMATRIX_H
#define PROJEKAT2_TESTMATRIX_H

void testMatrixSum();

#endif //PROJEKAT2_TESTMATRIX_H
